package com.android.store.timewise

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Sign In activity buttons and edit texts.
        val buttonLogin = findViewById<Button>(R.id.btnLogin)
        val editTextUsername = findViewById<EditText>(R.id.etUsername)
        val editTextPassword = findViewById<EditText>(R.id.etPassword)
        val textViewRegister = findViewById<TextView>(R.id.tvRegister)


        //Onclick Listener to open the registration tab
        textViewRegister.setOnClickListener{
            //Register Intent
            val intentRegister = Intent(this, RegisterActivity:: class.java)
            startActivity(intentRegister)

        }

        //Onclick Listener to open Home page from Login Tab
        buttonLogin.setOnClickListener{

            val intentHome = Intent(this, HomeActivity::class.java)
            startActivity(intentHome)





        }

    }
}