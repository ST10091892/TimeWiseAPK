package com.android.store.timewise

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)


        val buttonRegister = findViewById<Button>(R.id.btnRegister)
        val buttonBack = findViewById<Button>(R.id.btnBack)

        //Onclick Listener to open Home page from Registration Tab
        buttonRegister.setOnClickListener{
            val intentRegister = Intent(this, HomeActivity::class.java)
            startActivity(intentRegister)
            Toast.makeText(this, "CONGRATULATIONS! YOU HAVE BEEN SUCCESSFULLY REGISTERED", Toast.LENGTH_LONG).show()
        }

        //Onclick Listener to open the Login Tab from Registration Tab
        buttonBack.setOnClickListener{
            val intentBack = Intent(this, LoginActivity::class.java)
            startActivity(intentBack)
        }
    }
}