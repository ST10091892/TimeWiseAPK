package com.android.store.timewise

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Variables for onclicklisteners
        val imageviewTimeTracker = findViewById<ImageView>(R.id.ivTimeTracker)
        val textviewTimeTracker= findViewById<TextView>(R.id.tvTimeTracker)

        val imageviewCalendar = findViewById<ImageView>(R.id.ivCalendar)
        val textviewCalendar= findViewById<TextView>(R.id.tvCalendar)

        val imageviewReport = findViewById<ImageView>(R.id.ivReport)
        val textviewReport= findViewById<TextView>(R.id.tvReport)

        val imageviewSettings = findViewById<ImageView>(R.id.ivSettings)
        val textviewSettings= findViewById<TextView>(R.id.tvSettings)



        //On click listener for Time Tracker
        imageviewTimeTracker.setOnClickListener{
            val intentTimeTracker = Intent(this, TimeTrackerActivity:: class.java)
            startActivity(intentTimeTracker)
        }
        textviewTimeTracker.setOnClickListener{
            val intentTimeTracker = Intent(this, TimeTrackerActivity:: class.java)
            startActivity(intentTimeTracker)
        }

        //On click listener for Calendar
        imageviewCalendar.setOnClickListener{
            val intentCalendar = Intent(this, CalendarActivity:: class.java)
            startActivity(intentCalendar)
        }
        textviewCalendar.setOnClickListener{
            val intentCalendar = Intent(this, CalendarActivity:: class.java)
            startActivity(intentCalendar)
        }

        //On click listener for Report
        imageviewReport.setOnClickListener{
            val intentReport = Intent(this, ReportActivity:: class.java)
            startActivity(intentReport)
        }
        textviewReport.setOnClickListener{
            val intentReport = Intent(this, ReportActivity:: class.java)
            startActivity(intentReport)
        }

        //On click listener for Settings
        imageviewSettings.setOnClickListener{
            val intentSettings = Intent(this, SettingsActivity:: class.java)
            startActivity(intentSettings)
        }
    }
}